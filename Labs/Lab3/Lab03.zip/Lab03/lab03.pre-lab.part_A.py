
A = 3 * "125"
print( "Value of A:", A )            # Value of A: ____________

B = 3 * int( "125" )
print( "Value of B:", B )            # Value of B: ____________

C = 3 * str( 125 )
print( "Value of C:", C )            # Value of C: ____________

D = "a" + "bc" * 2
print( "Value of D:", D )            # Value of D: ____________

E = ("A" + "BC") * 2
print( "Value of E:", E )            # Value of E: ____________

F = "a" in "aardvark"
print( "Value of F:", F )            # Value of F: ____________

G = "ad" in "aardvark"
print( "Value of G:", G )            # Value of G: ____________

ZZZ = "Arthur, King of the Britons"

H = ZZZ[:4]
print( "Value of H:", H )            # Value of H: ____________

I = ZZZ[-3:]
print( "Value of I:", I )            # Value of I: ____________

J = ZZZ[-6:-2]
print( "Value of J:", J )            # Value of J: ____________
