
S1 = "Tiger"
S2 = "tiger"

A = S1 == S2
print( "Value of A:", A )            # Value of A: ____________

B = S1 > S2
print( "Value of B:", B )            # Value of B: ____________

C = S1[0] != S2[0]
print( "Value of C:", C )            # Value of C: ____________

D = S1[-1] == S2[-1]
print( "Value of D:", D )            # Value of D: ____________

S3 = "aardvark"
S4 = "anteater"

E = S3 == S4
print( "Value of E:", E )            # Value of E: ____________

F = S3 < S4
print( "Value of F:", F )            # Value of F: ____________

G = len(S3) == len(S4)
print( "Value of G:", G )            # Value of G: ____________

S5 = "ants"
S6 = "anteater"

H = S5 < S6
print( "Value of H:", H )            # Value of H: ____________

I = len(S5) < len(S6)
print( "Value of I:", I )            # Value of I: ____________

J = S5[0] != S6[0]
print( "Value of J:", J )            # Value of J: ____________

K = S5[-1] == S6[-1]
print( "Value of K:", K )            # Value of K: ____________
