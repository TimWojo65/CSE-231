VOWELS = "aeiou"
word = input(":~Enter a word ('quit' to quit)~:")
        
# Error message used in Codio test
#print("Can't convert an empty string. Try again.")
    
    
    
