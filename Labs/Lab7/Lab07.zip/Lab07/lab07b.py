"{:10s} {:10s}".format("Name", "Total")
"{:10s} {:<10d}"
