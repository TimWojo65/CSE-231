"\n:~Input a battle logs file ~:"
"File Not Found - You got sniped!"


#String formatting for the header
"{:<16s}{:>16s}{:>16s}{:>16s}{:>16s}"

#string formatting for each row in the table
"{:<16s}{:>16d}{:>16d}{:>16d}{:>16.2f}"

#string formatting for the average, max, min, and kpm
"{:<16s}{:>16.2f}{:>16.2f}{:>16.2f}{:>16.2f}"

