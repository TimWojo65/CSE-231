################################################################################
#
# Computer Project 04
#
#
#
#
#
#
#
#
#
################################################################################




# --- Banner (read-only) ---
banner = r'''
    TRAFFIC LIGHT FSM
    ------------------
        +-----------+
        |   [RED]   |
        | [YELLOW]  |
        |  [GREEN]  |
        +-----------+
    Pedestrian Button + Timer
    -----------------
'''

#------- states------
"INIT"
"GREEN"
"GREEN_WAIT"
"YELLOW"
"RED"
"FLASH_YELLOW"
"SINK"

# use these strings in your input and print statements.
":~Enter a sequence (t,e,p,r,w). Empty line = quit ~:"
"Error: sequence must be at least 3 characters.\n"
"You entered: {}"
"Invalid sequence -- ended in SINK.\n"
"Valid sequence -- final state: {}\n"
"Goodbye!"


# All your functions definition starts here




def main():

    pass # replace with you code for main function



# These two lines allow this program to be imported into other code
# such as our function_test code allowing other functions to be run
# and tested without 'main' running.  However, when this program is
# run alone, 'main' will execute.  
if __name__ == "__main__": 
    main()
