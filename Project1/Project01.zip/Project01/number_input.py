# first program in python
# input two numbers, add them together, print them out
# use this file as an example to show you how to ask for input and print
#results

num_str_one = input(':~Please enter an integer ~:')
num_str_two = input(':~Please enter a floating point number ~:')

int_one = int(num_str_one)
float_one = float(num_str_two)

print("The numbers are:", int_one, "and", float_one)
print("Their sum is:", int_one+float_one, "Their product is:",int_one*float_one)
