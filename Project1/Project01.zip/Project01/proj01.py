###################################################################################
#
# Computer Project 01
#
#
#
#
#
#
#
#
#
###################################################################################


# use the following strings in your input statements
"\n:~Input rods ~:"

# the following 2 strings should be in the same print statement
#seperated by the input rods
"\nYour value is"
"rods."

# use the following strings in your print statements
"\nConversions:"
"Meters:"
"Feet:"
"Miles:"
"Furlongs:"
"Time to walk", rods_flt, "rods is", minutes_flt, "minutes."

