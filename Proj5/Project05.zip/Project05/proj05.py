################################################################################
#
# Computer Project 05
#
#
#
#
#
#
#
#
#
################################################################################


import csv
from operator import itemgetter

# --- Menu and injury_lst (read-only) ---
menu = '''
    Menu : 
        1: The maximum exercise time a pet received
        2: Individual pet information
        3: The pets with abnormal diet conditions
        4: Top 5 pets in exercise time
        5: The pets with injury records
        6: The number of pets who took vaccines no more than X
        7: Top 10 pets in overall score ranking
        X: Exit
'''

injury_lst = ["Burn", "Bite", "Cut", "Scratch"]



# use these strings in your input and print statements.
"\n:~Enter a pet names file ~:"
"\n:~Enter a Diet record file ~:"
"\n:~Enter a Exercise record file ~:"
"\n:~Enter a Health record file ~:"
"Error. File does not exist"
"\nThank you and Good Bye"

"\n:~Input a choice ~:"
"Error: Invalid choice. Please enter a valid choice."

#------------------option 1
"\n--------------"
"Maximum exercise time: {} minutes"
"Pet name(s): {}"

#----------------option 2
"\n:~Enter a pet name ~:"
"Invalid name or does not exist"

"\n--------------"
"Diet:\n\tMeal frequency: {}\n\tNutritional Balance:\n\t\tProtein: {}\n\t\tFat: {}"

"\n--------------"
"Exercise:\n\tWalk(s): {}\n\tPlay time: {}"

"\n--------------"
"Health:\n\tVaccines taken: {}\n\tInjury reports: {}"

#------------option 3
"\n--------------"
"The number of pets with abnormal diet conditions: {}"
"\t{}:\n\t Meal: {}, Protein: {}, Fat: {}"

#------------option 4
"\n--------------"
"{}: {}"

#------------option 5
"\n--------------"
"{}: {}"

#------------option 6
"\n:~Enter the vaccine number ~:"
"Invalid input"
"Number of pet(s): {}"

#------------option 7
"\n--------------"
"{}: {}"



# All your functions definition starts here

def open_file(message):

    pass # replace with your code



def read_files(fp_names, fp_diet, fp_exercise, fp_health):

    pass # replace with your code





def main():

    pass # replace with your code for main function



# These two lines allow this program to be imported into other code
# such as our function_test code allowing other functions to be run
# and tested without 'main' running.  However, when this program is
# run alone, 'main' will execute.
if __name__ == "__main__":
    main()